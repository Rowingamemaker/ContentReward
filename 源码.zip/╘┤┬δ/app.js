// 初始化AV

// 授权登录
App({
  onLaunch: function () {
    // auto login via SD
  }
})

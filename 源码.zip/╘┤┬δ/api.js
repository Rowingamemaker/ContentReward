var _api_root = 'https://pcwq.stqckj.com/api/portal/';
import { wxGet, wxPost, uploadFile } from '/utils/wxRequest.js';
import { getLocation, chooseLocation } from '/utils/common.js';
var api = {
  //微信登陆
  wxLogin(data) {
    let url = _api_root + 'wxLogin';
    return wxPost(url, data);
    // console.log(res)
  },
  getMy() {
    let url = _api_root + 'articles/getmy';
    return wxGet(url);
  },  
  //商务合作
  getHeZuo() {
    let url = _api_root + 'pages/getHeZuo';
    return wxGet(url);
  },
  //下单记录
  orderLog(data) {
    let url = _api_root + 'pages/orderLog';
    return wxPost(url, data);
  },
  get_openid(data) {
    let url = _api_root + 'pages/get_openid';
    return wxPost(url, data);
  },
  //banner
  getBanner: (() => {
    let url = _api_root + 'pages/banner';
    return wxGet(url);
  }),
  // getBanner() {
  // let url = _api_root + 'pages/banner';
  // return wxGet(url);
  // },
  //nav
  getNav() {
    let url = _api_root + 'pages/nav';
    return wxGet(url);
  },
  //nav
  getTab() {
    let url = _api_root + 'categories/tab';
    return wxGet(url);
  },
  getTab1() {
    let url = _api_root + 'categories/tab1';
    return wxGet(url);
  },
  //
  getArticles(data) {
    let url = _api_root + 'articles/getArticles';
    return wxPost(url, data);
  },
  getRead(data) {
    let url = _api_root + 'articles/read';
    return wxPost(url, data);
  },
  getRead1(data) {
    let url = _api_root + 'articles/read1';
    return wxPost(url, data);
  }
};
module.exports = api;
var app = getApp()
import { getBanner, getNav, getTab, getTab1, get_openid, getRead1 } from '../../api.js';

Page({
  data: {
    imgUrls: [

    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    windowWidth: 320,
    sortPanelTop: '0',
    sortPanelDist: '290',
    sortPanelPos: 'relative',
    noticeIdx: 0,
    currentIndex: 0,
    winWidth: 0,
    winHeight: 0,
    // tab切换  
    currentTab: 0,
    animationNotice: {},
    bannerList: [],
    navList: [],
    display: false,
  },
  look: function (e) {
    console.log(e);
    var id = e.currentTarget.dataset.id;

    wx.navigateTo({
      url: '../pay/pay?id=' + id,
    })



    // wx.navigateTo({
    //   url: '../look/look?id=' + id,
    // })

  },
  pud: function (e) {
    console.log(e);
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../pay/pay?id=' + id,
    })
  },
  pay: function () {
    var that = this;
    var money = that.data.money;
    var id = that.data.id;

    wx.getStorage({
      key: 'openid',
      success: function (res) {
        wx.request({
          //这里是后台的处理方法，url是自定义的，直接换成你自己的后台处理方法即可，Wx_Pay这个方法在下面写的有
          //后台用的php做处理，java的可以参考方法，道理都是一样的
          url: 'https://stqckj.com/5.22/public/api/portal/lists/Wx_Pay',
          data: {
            //用户的openid
            openid: res.data,
            fee: money,  //支付金额
            details: 'test',//支付商品的名称
          },
          success: function (result) {
            console.log("pay")
            console.log(result)
            if (result.data) {
              //out_trade_no=res.data['out_trade_no'];
              wx.requestPayment({
                timeStamp: result.data['timeStamp'],
                nonceStr: result.data['nonceStr'],
                package: result.data['package'],
                signType: 'MD5',
                paySign: result.data['paySign'],
                'success': function (res) {
                  that.setData({
                    display: false,
                  })
                  if (res.errMsg == "requestPayment:ok") {
                    orderLog({ 'post_id': id, 'money': money }).then(res => {
                      wx.navigateTo({
                        url: '../look/look?id=' + id,
                      })
                    })
                  }
                },
                'fail': function (res) {
                  that.setData({
                    display: false,
                  })
                  orderLog({ 'post_id': id, 'money': money }).then(res => {
                    console.log(res);
                  })
                }
              })
            }
          }
        })
      },
    })
  },
  pud1: function (e) {
    console.log(e);
    var id = e.currentTarget.dataset.id;
    var money = e.currentTarget.dataset.money;

    getRead1({ 'id': id }).then(res => {
      console.log(res)
      if (res.data == 1) {
        if (id != '') {
          var money = that.data.money;

        }
      }
    })
  },
  onReady: function () {

  },
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  onAside: function (options) {
    //console.log(options)
    //下标
    var index = options.currentTarget.dataset.index;
    console.log(index)
    this.setData({
      currentIndex: index
    });
  },
  onLoad: function () {
    var pages = this;
    wx.getStorage({
      key: 'openid',
      success: function (res) {
        if (res.data == '') {
          wx.login({
            success: function (res) {
              console.log(res.code);
              get_openid({ 'code': res.code }).then(res => {
                console.log(res);
                let openId = res.data.data.openid;
                wx.setStorage({ key: 'openid', data: openId, })
              })
            },
          })
        }
      },
      fail: function (res) {
        wx.login({
          success: function (res) {
            console.log(res.code);
            get_openid({ 'code': res.code }).then(res => {
              console.log(res);
              let openId = res.data.data.openid;
              wx.setStorage({ key: 'openid', data: openId, })
            })
          },
        })
      }
    })

    getBanner().then(res => {
      console.log(res.data.data);
      if (res.data.code == 1) {
        pages.setData({
          bannerList: res.data.data
        })
      }
    })
    getNav().then(res => {
      console.log(res.data.data);
      if (res.data.code == 1) {
        pages.setData({
          navList: res.data.data
        })
      }
    });
    getTab().then(res => {
      console.log(res);
      pages.setData({
        categoryData1: res.data.data,
      })
    })
    getTab1().then(res => {
      console.log(res);
      pages.setData({
        categoryData: res.data.data,
      })
    })

    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
    var me = this;
    var animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'ease-out',
    });
    me.animation = animation;
    wx.getSystemInfo({
      success: function (res) {
        me.setData({ windowWidth: res.windowWidth })
      }
    });

    console.log('onLoad');
  },
  startNotice: function () {
    var me = this;
    var notices = me.data.notices || [];
    if (notices.length == 0) {
      return;
    }

    var animation = me.animation;
    //animation.translateY( -12 ).opacity( 0 ).step();
    animation.translateY(0).opacity(1).step({ duration: 0 });
    me.setData({ animationNotice: animation.export() });

    var noticeIdx = me.data.noticeIdx + 1;
    if (noticeIdx == notices.length) {
      noticeIdx = 0;
    }

    // 更换数据
    setTimeout(function () {
      me.setData({
        noticeIdx: noticeIdx
      });
    }, 400);

    // 启动下一次动画
    setTimeout(function () {
      me.startNotice();
    }, 5000);
  },
  onShow: function () {
    this.startNotice();

  },
  onToTop: function (e) {
    if (e.detail.scrollTop >= 290) {
      this.setData({ sortPanelPos: 'fixed' });
    } else {
      this.setData({ sortPanelPos: 'relative' });
    }
    console.log(e.detail.scrollTop)
  },
  onShareAppMessage:function(){
    return {
      title: '有群有趣，群策群力',
      path: '/pages/index/index',
      imageUrl: '/images/5.30_2.png',
      success: function (res) {
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})

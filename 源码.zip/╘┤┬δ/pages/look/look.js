// pages/look/look.js
var WxParse = require('../../wxParse/wxParse.js');
import { getRead } from '../../api.js';

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  pay: function () {
    var that = this
    wx.getStorage({
      key: 'openid',
      success: function (res) {
        wx.request({
          //这里是后台的处理方法，url是自定义的，直接换成你自己的后台处理方法即可，Wx_Pay这个方法在下面写的有
          //后台用的php做处理，java的可以参考方法，道理都是一样的
          url: url + 'Wx_Pay',
          data: {
            //用户的openid
            openid: res.data,
            fee: that.data.totalPrice,  //支付金额
            details: that.data.goodsList[0].goods_name,//支付商品的名称
          },
          success: function (result) {
            if (result.data) {
              //out_trade_no=res.data['out_trade_no'];
              wx.requestPayment({
                timeStamp: result.data['timeStamp'],
                nonceStr: result.data['nonceStr'],
                package: result.data['package'],
                signType: 'MD5',
                paySign: result.data['paySign'],
                'success': function (successret) {
                  console.log('支付成功');
                  //获取支付用户的信息
                  wx.getStorage({
                    key: 'userInfo',
                    success: function (getuser) {
                      //加入订单表做记录
                      wx.request({
                        url: url + 'Wx_AddOrder',
                        data: {
                          uname: getuser.data.nickName,
                          goods: that.data.goodsList[0].goods_name,
                          price: that.data.totalPrice,
                          openid: res.data,
                        },
                        success: function (lastreturn) {
                          console.log("存取成功");
                        }
                      })
                    },
                  })
                }, 'fail': function (res) {
                }
              })
            }
          }
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    var id = options.id;
    // var id = 381;
    var pages = this;
    getRead({ 'id': id }).then(res => {
      console.log(res);
      if (res.data.code == 1) {
        var data = res.data.data.post_content;
        console.log(data);
        WxParse.wxParse('article', 'html', data, pages, 5);
        // pages.setData({
        //   lists: data
        // })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '有群有趣，群策群力',
      path: '/pages/index/index',
      imageUrl: '/images/5.30_2.png',
      success: function (res) {
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})
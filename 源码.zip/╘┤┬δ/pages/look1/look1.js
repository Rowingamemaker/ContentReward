// pages/look1/look1.js
var WxParse = require('../../wxParse/wxParse.js');
import { getHeZuo } from '../../api.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pages = this;
    getHeZuo().then(res => {
      var post_content = res.data.post_content
      WxParse.wxParse('article', 'html', post_content, pages, 5);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '有群有趣，群策群力',
      path: '/pages/index/index',
      imageUrl: '/images/5.30_2.png',
      success: function (res) {
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})
// pages/pay/pay.js
import { getArticles, orderLog } from '../../api.js';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: "",
    bookList: null,
    count: 4,
    view_show: false,
    lists: [],
    display: false,
    lookid: '',//转发看的
    flag: 0,
    page: 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    var id = options.id;
    // var id = 32;
    var pages = this;
    var page = this.data.page;
    getArticles({ 'id': id, 'page': page }).then(res => {
      console.log(res);
      if (res.data.code == 1) {
        var data = res.data.data;
        pages.setData({
          lists: data,
          id: id,
          page: ++page
        })
      }
    })
  },
  pay: function () {
    var that = this;
    var money = that.data.money;
    var id = that.data.id;
    console.log('文章id')
    console.log(id);
    if (money == 0) {
      wx.navigateTo({
        url: '../look/look?id=' + id,
      })
    } else {
      wx.getStorage({
        key: 'openid',
        success: function (res) {
          wx.request({
            //这里是后台的处理方法，url是自定义的，直接换成你自己的后台处理方法即可，Wx_Pay这个方法在下面写的有
            //后台用的php做处理，java的可以参考方法，道理都是一样的
            url: 'https://pcwq.stqckj.com/api/portal/lists/wxpay',
            data: {
              //用户的openid
              openid: res.data,
              fee: money,  //支付金额
              details: 'test',//支付商品的名称
            },
            success: function (result) {
              console.log("pay")
              console.log(result)
              if (result.data) {
                wx.requestPayment({
                  timeStamp: result.data['timeStamp'],
                  nonceStr: result.data['nonceStr'],
                  package: result.data['package'],
                  signType: 'MD5',
                  paySign: result.data['paySign'],
                  'success': function (res) {
                    that.setData({
                      display: false,
                    })
                    if (res.errMsg == "requestPayment:ok") {
                      orderLog({ 'post_id': id, 'money': money }).then(res => {
                        // wx.getStorage({
                        //   key: 'paylook',
                        //   success: function (res) {
                        //     let paylook = res.data;
                        //     paylook = paylook + ',' + id;
                        //     wx.setStorage({
                        //       key: 'paylook',
                        //       data: paylook,
                        //     })
                        //   },
                        //   fail: function (res) {
                        //     let paylook = id + '';
                        //     wx.setStorage({
                        //       key: 'paylook',
                        //       data: paylook,
                        //     })
                        //   },
                        //   complete: function (res) { },
                        // })
                        wx.navigateTo({
                          url: '../look/look?id=' + id,
                        })
                      })
                    }
                  },
                  'fail': function (res) {
                    that.setData({
                      display: false,
                    })
                  }
                })
              }
            }
          })
        }
      })
    }
  },
  // pay: function () {
  //   var that = this;
  //   var money = that.data.money;
  //   var id = that.data.id;
  //   console.log('文章id')
  //   console.log(id);
  //   if (money == 0) {
  //     wx.navigateTo({
  //       url: '../look/look?id=' + id,
  //     })
  //   } else {
  //     wx.getStorage({
  //       key: 'openid',
  //       success: function (res) {
  //         wx.request({
  //           //这里是后台的处理方法，url是自定义的，直接换成你自己的后台处理方法即可，Wx_Pay这个方法在下面写的有
  //           //后台用的php做处理，java的可以参考方法，道理都是一样的
  //           url: 'https://pcwq.stqckj.com/api/portal/lists/wxpay',
  //           data: {
  //             //用户的openid
  //             openid: res.data,
  //             fee: money,  //支付金额
  //             details: 'test',//支付商品的名称
  //           },
  //           success: function (result) {
  //             console.log("pay")
  //             console.log(result)
  //             if (result.data) {
  //               wx.requestPayment({
  //                 timeStamp: result.data['timeStamp'],
  //                 nonceStr: result.data['nonceStr'],
  //                 package: result.data['package'],
  //                 signType: 'MD5',
  //                 paySign: result.data['paySign'],
  //                 'success': function (res) {
  //                   that.setData({
  //                     display: false,
  //                   })
  //                   if (res.errMsg == "requestPayment:ok") {
  //                     orderLog({ 'post_id': id, 'money': money }).then(res => {
  //                       wx.getStorage({
  //                         key: 'paylook',
  //                         success: function (res) {
  //                           let paylook = res.data;
  //                           paylook = paylook + ',' + id;
  //                           wx.setStorage({
  //                             key: 'paylook',
  //                             data: paylook,
  //                           })
  //                         },
  //                         fail: function (res) {
  //                           let paylook = id + '';
  //                           wx.setStorage({
  //                             key: 'paylook',
  //                             data: paylook,
  //                           })
  //                         },
  //                         complete: function (res) { },
  //                       })
  //                       wx.navigateTo({
  //                         url: '../look/look?id=' + id,
  //                       })
  //                     })
  //                   }
  //                 },
  //                 'fail': function (res) {
  //                   that.setData({
  //                     display: false,
  //                   })
  //                 }
  //               })
  //             }
  //           }
  //         })
  //       }
  //     })
  //   }
  // },
  look: function (e) {
    console.log(e);
    var pages = this;
    if (pages.data.display) {
      pages.setData({
        display: false,
      })
    } else {
      var id = e.currentTarget.dataset.id;
      var money = e.currentTarget.dataset.money;
      var flag = e.currentTarget.dataset.flag
      pages.setData({
        display: true,
        id: id,
        money: money,
        flag: flag
      })

    }
  },
  // look: function (e) {
  //   console.log(e);
  //   var pages = this;
  //   if (pages.data.display) {
  //     pages.setData({
  //       display: false,
  //     })
  //   } else {
  //     var id = e.currentTarget.dataset.id;
  //     var money = e.currentTarget.dataset.money;
  //     var flag = e.currentTarget.dataset.flag;

  //     pages.setData({
  //       lookid: id,
  //       flag: flag
  //     })
  //     if (money == 0 || money == '') {
  //       wx.navigateTo({
  //         url: '../look/look?id=' + id,
  //       })
  //     } else {
  //       wx.getStorage({
  //         key: 'paylook',
  //         success: function (res) {
  //           let paylook = res.data;
  //           var arr = paylook.split(',');
  //           var flag = false;
  //           for (var i in arr) {
  //             if (id == arr[i]) {

  //               flag = true;
  //             }
  //           }
  //           if (flag) {
  //             wx.navigateTo({
  //               url: '../look/look?id=' + id,
  //             })
  //           } else {
  //             pages.setData({
  //               display: true,
  //               id: id,
  //               money: money,
  //             })
  //           }
  //         },
  //         fail: function (res) {
  //           pages.setData({
  //             display: true,
  //             id: id,
  //             money: money,
  //           })
  //         },
  //         complete: function (res) { },
  //       })
  //     }
  //   }
  // },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    // var pages = this;
    // var page = pages.data.page;
    // var dataList = pages.data.lists;
    // var id = pages.data.id;
    // getArticles({ 'id': id, 'page': page }).then(res => {
    //   console.log(res);
    //   if (res.data.code == 1) {
    //     var data = res.data.data.data;
    //     dataList = dataList.concat(data);
    //     console.log(data)
    //     pages.setData({
    //       lists: dataList,
    //       id: id,
    //       page: ++page
    //     })
    //   }
    // })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    this.setData({
      display: false,
    })
    var lookid = this.data.id;
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '有群有趣，群策群力',
      path: '/pages/index/index',
      imageUrl: '/images/5.30_2.png',
      success: function (res) {
        console.log(res);
        // 转发成功
        if (res.errMsg == 'shareAppMessage:ok') {
          orderLog({ 'flag': 1, 'post_id': lookid }).then(res => {
            wx.navigateTo({
              url: '../look/look?id=' + lookid,
            })
          })
        }

      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})
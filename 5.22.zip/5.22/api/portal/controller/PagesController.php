<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2017 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: pl125 <xskjs888@163.com>
// +----------------------------------------------------------------------

namespace api\portal\controller;

use cmf\controller\RestBaseController;
use api\portal\model\PortalPostModel;
use think\Db;
use think\Request;

class PagesController extends RestBaseController
{
    protected $postModel;
    public function test(){
        $res=Db::name('order')->where('post_id',364)->count();
        var_dump($res);
        die();

    }
    public function __construct(PortalPostModel $postModel)
    {
        parent::__construct();
        $this->postModel = $postModel;
    }
    public function getHeZuo(){
        $hezuo=Db::name('hezuo')->where('id',1)->find();
        return json($hezuo);
    }

    public function orderLog()
    {
        $params = input();
        $category_id=Db::name('portal_category_post')->where('post_id',$params['post_id'])->order('id','desc')->value('category_id');
        $category_name=Db::name('portal_category')->where('id',$category_id)->value('name');
        $where = array(
            'money' => $params['money'],
            'post_id' => $params['post_id'],
            'create_time'=>time(),
            'category_id'=>$category_id,
            'order_sn'=>time(),
            'category_name'=>$category_name
        );
        Db::name('order')->insert($where);
    }

    public function get_openid($code)
    {
        $appid = 'wxb09790a7e9107f77';
        $appsecret = '9bf0f884806920e7901b4f7aa836c9e7';
        $url = "https://api.weixin.qq.com/sns/jscode2session?appid=$appid&secret=$appsecret&js_code=$code&grant_type=authorization_code";
        $res = $this->curl_get($url);
        $result = json_decode($res, true);
        if (!empty($result['openid'])) {
            return $this->returnData('1', 'openid成功', $result);
        }
        return false;
    }

    //get方法
    function curl_get($url, &$httpCode = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        //不做证书验证.部署在linux环境下请改为true
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        $file_contents = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $file_contents;
    }

    public function wxLogin()
    {

        $params = Request::param();
        if (!isset($params['code'])) {
            return $this->returnData('-1', '参数错误,登录失败');
        }
        $openId = get_openid($params['code']);
        if (!$openId) {
            return $this->returnData('-1', 'openid的问题呀~~~登录失败');
        }
        $data = [];
        $res = '';
        $avatarUrl = '';
        $nickName = '';
        if (isset($params['avatarUrl'])) {
            $avatarUrl = $params['avatarUrl'];
            $nickName = $params['nickName'];
        }

        if ($res) {
            return $this->returnData('1', '登录成功', $data);
        }
        return $this->returnData('-1', '登录失败');
    }


    function returnData($code = 1, $msg = '', $data = [])
    {
        return json(array(
            'code' => $code,
            'msg' => $msg,
            'data' => $data
        ));
    }


    public function banner()
    {
        $params = $this->request->get();
        $params['where']['is_banner'] = 1;
        $params['order'] = '-id';
        $data = $this->postModel->getDatas($params);
        $this->success('请求成功!', $data);
    }

    public function nav()
    {
        $params = $this->request->get();
        $params['where']['is_nav'] = 1;
        $params['order'] = '-id';
        $data = $this->postModel->getDatas($params);
        $this->success('请求成功!', $data);
    }

    /**
     * 页面列表
     */
    public function index()
    {
        $params = $this->request->get();
        $params['where']['post_type'] = 2;
        $params['order'] = '-id';
        $data = $this->postModel->getDatas($params);
        $this->success('请求成功!', $data);
    }

    /**
     * 获取页面
     * @param int $id
     */
    public function read($id)
    {
        $params = $this->request->get();
        $params['where']['post_type'] = 2;
        $params['id'] = $id;
        $data = $this->postModel->getDatas($params);
        $this->success('请求成功!', $data);
    }
}

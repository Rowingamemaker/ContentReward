<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2017 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: wuwu <15093565100@163.com>
// +----------------------------------------------------------------------
namespace api\portal\controller;

use api\portal\model\PortalCategoryModel;
use api\portal\model\PortalPostModel;
use cmf\controller\RestBaseController;
use think\Db;
use think\Request;

class ListsController extends RestBaseController
{

    public function test1(){
        echo '1';
    }
    public function wxPay(){
        $request=Request::instance();
        $fee=$request->param('fee');
        $details=$request->param('details');//商品的详情，比如iPhone8，紫色
        // $fee = 0.01;//举例充值0.01
        $appid =        'wxb09790a7e9107f77';//appid
        $body =        'body测试';// '金邦汇商城';//'【自己填写】'
        $mch_id =       '1495013842';//'你的商户号【自己填写】'
        $nonce_str =    $this->nonce_str();//随机字符串
        $notify_url =   'https://zys.jinbh.cn/admin/Api/Wx_Speech';//回调的url【自己填写】';
        $openid =       $request->param('openid');//'用户的openid【自己填写】';
        $out_trade_no = $this->order_number($openid);//商户订单号
        $spbill_create_ip = '192.168.1.188';//'服务器的ip【自己填写】';
        $total_fee =    $fee*100;//因为充值金额最小是1 而且单位为分 如果是充值1元所以这里需要*100
        $trade_type = 'JSAPI';//交易类型 默认
        //这里是按照顺序的 因为下面的签名是按照顺序 排序错误 肯定出错
        $post['appid'] = $appid;
        $post['body'] = $body;

        $post['mch_id'] = $mch_id;

        $post['nonce_str'] = $nonce_str;//随机字符串

        $post['notify_url'] = $notify_url;

        $post['openid'] = $openid;

        $post['out_trade_no'] = $out_trade_no;

        $post['spbill_create_ip'] = $spbill_create_ip;//终端的ip

        $post['total_fee'] = $total_fee;//总金额 最低为一块钱 必须是整数

        $post['trade_type'] = $trade_type;
        $sign = $this->sign($post);//签名
        $post_xml = '<xml>
           <appid>'.$appid.'</appid>
           <body>'.$body.'</body>
           <mch_id>'.$mch_id.'</mch_id>
           <nonce_str>'.$nonce_str.'</nonce_str>
           <notify_url>'.$notify_url.'</notify_url>
           <openid>'.$openid.'</openid>
           <out_trade_no>'.$out_trade_no.'</out_trade_no>
           <spbill_create_ip>'.$spbill_create_ip.'</spbill_create_ip>
           <total_fee>'.$total_fee.'</total_fee>
           <trade_type>'.$trade_type.'</trade_type>
           <sign>'.$sign.'</sign>
        </xml> ';
        //统一接口prepay_id
        $url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
        $xml = $this->http_request($url,$post_xml);
        $array = $this->xml($xml);//全要大写
        if($array['RETURN_CODE'] == 'SUCCESS' && $array['RESULT_CODE'] == 'SUCCESS'){
            $time = time();
            $tmp='';//临时数组用于签名
            $tmp['appId'] = $appid;
            $tmp['nonceStr'] = $nonce_str;
            $tmp['package'] = 'prepay_id='.$array['PREPAY_ID'];
            $tmp['signType'] = 'MD5';
            $tmp['timeStamp'] = "$time";

            $data['state'] = 1;
            $data['timeStamp'] = "$time";//时间戳
            $data['nonceStr'] = $nonce_str;//随机字符串
            $data['signType'] = 'MD5';//签名算法，暂支持 MD5
            $data['package'] = 'prepay_id='.$array['PREPAY_ID'];//统一下单接口返回的 prepay_id 参数值，提交格式如：prepay_id=*
            $data['paySign'] = $this->sign($tmp);//签名,具体签名方案参见微信公众号支付帮助文档;
            $data['out_trade_no'] = $out_trade_no;

        }else{
            $data['state'] = 0;
            $data['text'] = "错误";
            $data['RETURN_CODE'] = $array['RETURN_CODE'];
            $data['RETURN_MSG'] = $array['RETURN_MSG'];
        }
        return  json($data);
    }


    //随机32位字符串
    private function nonce_str(){
        $result = '';
        $str = 'QWERTYUIOPASDFGHJKLZXVBNMqwertyuioplkjhgfdsamnbvcxz';
        for ($i=0;$i<32;$i++){
            $result .= $str[rand(0,48)];
        }
        return $result;
    }


    //生成订单号
    private function order_number($openid){
        //date('Ymd',time()).time().rand(10,99);//18位
        return md5($openid.time().rand(10,99));//32位
    }




    //签名 $data要先排好顺序
    public function sign($data)
    {
        $stringA = '';
        foreach ($data as $key => $value) {
            if (!$value) continue;
            if ($stringA) $stringA .= '&' . $key . "=" . $value;
            else $stringA = $key . "=" . $value;
        }
        $wx_key = '78e14608d706f8f8e42ca5206358e814';//申请支付后有给予一个商户账号和密码，登陆后自己设置key
        $stringSignTemp = $stringA . '&key=' . $wx_key;//申请支付后有给予一个商户账号和密码，登陆后自己设置key
        return strtoupper(md5($stringSignTemp));
    }

    //curl请求啊
    function http_request($url, $data = null, $headers = array())
    {
        $curl = curl_init();
        if (count($headers) >= 1) {
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        }
        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);

        if (!empty($data)) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    //获取xml
    private function xml($xml){
        $p = xml_parser_create();
        xml_parse_into_struct($p, $xml, $vals, $index);
        xml_parser_free($p);
        $data = "";
        foreach ($index as $key=>$value) {
            if($key == 'xml' || $key == 'XML') continue;
            $tag = $vals[$value[0]]['tag'];
            $value = $vals[$value[0]]['value'];
            $data[$tag] = $value;
        }
        return $data;
    }

    public function banner()
    {
        $where = array(
            'is_banner' => 1,
            'delete_time' => 0
        );
        $banner = Db::name('portal_post')->where($where)->select();
        foreach ($banner as $key => $value) {
              $value['banner_img']=json_decode($value['more']);
              $banner[$key]=$value;
        }
        return json($banner);
    }
    //留言的邮件发送
    //邮件发送换行 /r/n
    public function sendEmail()
    {
        $content = input('content');
        $name = input('name');
        $tel = input('tel');
        if (($content != '') && ($name = !'') && ($tel != '')) {
            $address = '331247449@qq.com';
            $subject = '王玉清小程序代理留言';
            $message = '留言人的姓名是:' . $name . "<br>" .
                "留言人的电话是:" . $tel . "<br>" .
                "留言内容是:" . $content . "<br>";
            $this->sendSms();
            return cmf_send_email($address, $subject, $message);
        }
    }

    public function sendEmail1()
    {
        $content = input('content');
        $name = input('name');
        $tel = input('tel');
        if (($content != '') && ($name = !'') && ($tel != '')) {
            $address = '3389309663@qq.com';
            $subject = '厦门装修小程序';
            $message = '留言人的姓名是:' . $name . "<br>" .
                "留言人的电话是:" . $tel . "<br>" .
                "留言人的地址是:" . $content . "<br>";
            $this->sendSms1();
            return cmf_send_email($address, $subject, $message);
        }
    }

    //防伪码查询
    public function find()
    {
        $id = input('id');
        $url = 'http://fangwei.aiaitie.com/anticode/AntiCodeIndex';
        $arr = array(
            'id' => $id,
        );
        $res = $this->request_post($url, $arr);
        $res = str_replace('"', "'", $res);
        return $res;

    }

    //发送短信
    public function sendSms()
    {
        header('content-type:text/html;charset=utf-8');
        $sendUrl = 'http://v.juhe.cn/sms/send'; //短信接口的URL
        $smsConf = array(
            'key' => '624bd52c30a39e98bf26acaff46b62ec', //您申请的APPKEY
            'mobile' => '18810868683', //接受短信的用户手机号码
            'tpl_id' => '64289', //您申18810868683请的短信模板ID，根据实际情况修改
            'tpl_value' => '#code#=64289' //您设置的模板变量，根据实际情况修改
        );
        $content = $this->juhecurl($sendUrl, $smsConf, 1); //请求发送短信

        if ($content) {
            $result = json_decode($content, true);
            $error_code = $result['error_code'];
            if ($error_code == 0) {
                //状态为0，说明短信发送成功
                echo "短信发送成功,短信ID：" . $result['result']['sid'];
            } else {
                //状态非0，说明失败
                $msg = $result['reason'];
                echo "短信发送失败(" . $error_code . ")：" . $msg;
            }
        } else {
            //返回内容异常，以下可根据业务逻辑自行修改
            echo "请求发送短信失败";
        }
    }

    public function sendSms1()
    {
        header('content-type:text/html;charset=utf-8');
        $sendUrl = 'http://v.juhe.cn/sms/send'; //短信接口的URL
        $smsConf = array(
            'key' => '624bd52c30a39e98bf26acaff46b62ec', //您申请的APPKEY
            'mobile' => '15960827076', //接受短信的用户手机号码
            'tpl_id' => '71546', //您申18810868683请的短信模板ID，根据实际情况修改
            'tpl_value' => '#code#=64289' //您设置的模板变量，根据实际情况修改
        );
        $content = $this->juhecurl($sendUrl, $smsConf, 1); //请求发送短信

        if ($content) {
            $result = json_decode($content, true);
            $error_code = $result['error_code'];
            if ($error_code == 0) {
                //状态为0，说明短信发送成功
                echo "短信发送成功,短信ID：" . $result['result']['sid'];
            } else {
                //状态非0，说明失败
                $msg = $result['reason'];
                echo "短信发送失败(" . $error_code . ")：" . $msg;
            }
        } else {
            //返回内容异常，以下可根据业务逻辑自行修改
            echo "请求发送短信失败";
        }
    }
    public function test()
    {
        $where = array(
            'parent_id' => 0,
            'delete_time' => 0,
            //            'parent_id' => 34
        );
        $data = Db::name('portal_category')->where($where)->select();//生活娱乐下的省
        $data = (array)$data;
        var_dump((array)$data);
        foreach ($data as $key => &$value) {
            $where1 = array(
                'parent_id' => $value['id'],
                'delete_time' => 0,
            );
            $data1 = Db::name('portal_category')->where($where1)->select();//生活娱乐下的省

            foreach ($data1 as $key1 =>&$value1){
                $where1 = array(
                    'parent_id' => $value1['id'],
                    'delete_time' => 0,
                );
                $data2 = Db::name('portal_category')->where($where1)->select();//生活娱乐下的省
                $value1['data2']=$data2;
            }
            $value['data1']=$data1;
        }
        return json($data);
    }


    /**
     * [推荐文章列表]
     * @Author:   wuwu<15093565100@163.com>
     * @DateTime: 2017-07-17T11:36:51+0800
     * @since:    1.0
     */
    public function recommended()
    {
        $param = $this->request->param();
        $portalPostModel = new PortalPostModel();

        $param['where'] = ['recommended' => 1];

        $articles = $portalPostModel->getDatas($param);

        $this->success('ok', ['list' => $articles]);
    }

    /**
     * [getCategoryPostLists 分类文章列表]
     * @Author:    wuwu<15093565100@163.com>
     * @DateTime: 2017-07-17T15:22:41+0800
     * @since:    1.0
     */
    public function getCategoryPostLists()
    {
        $categoryId = $this->request->param('category_id', 0, 'intval');


        $portalCategoryModel = new  PortalCategoryModel();

        $findCategory = $portalCategoryModel->where('id', $categoryId)->find();

        //分类是否存在
        if (empty($findCategory)) {
            $this->error('分类不存在！');
        }

        $param = $this->request->param();

        $articles = $portalCategoryModel->paramsFilter($param, $findCategory->articles()->alias('post'))->select();

        if (!empty($param['relation'])) {
            if (count($articles) > 0) {
                $articles->load('user');
                $articles->append(['user']);
            }
        }

        $this->success('ok', ['data' => $articles]);
    }

    public function request_post($url = '', $post_data = array())
    {//url为必传  如果该地址不需要参数就不传
        if (empty($url)) {
            return false;
        }

        if (!empty($post_data)) {
            $params = '';
            foreach ($post_data as $k => $v) {
                $params .= "$k=" . urlencode($v) . "&";
                // $params.= "$k=" . $v. "&" ;
            }
            $params = substr($params, 0, -1);
        }
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        if (!empty($post_data))
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);
        return $data;
    }

    /**
     * 请求接口返回内容
     * @param  string $url [请求的URL地址]
     * @param  string $params [请求的参数]
     * @param  int $ipost [是否采用POST形式]
     * @return  string
     */
    public function juhecurl($url, $params = false, $ispost = 0)
    {
        $httpInfo = array();
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.172 Safari/537.22');
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($ispost) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            if ($params) {
                curl_setopt($ch, CURLOPT_URL, $url . '?' . $params);
            } else {
                curl_setopt($ch, CURLOPT_URL, $url);
            }
        }
        $response = curl_exec($ch);
        if ($response === FALSE) {
            //echo "cURL Error: " . curl_error($ch);
            return false;
        }
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $httpInfo = array_merge($httpInfo, curl_getinfo($ch));
        curl_close($ch);
        return $response;
    }

}

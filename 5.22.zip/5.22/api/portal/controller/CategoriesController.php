<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2017 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: pl125 <xskjs888@163.com>
// +----------------------------------------------------------------------

namespace api\portal\controller;

use cmf\controller\RestBaseController;
use api\portal\model\PortalCategoryModel;
use think\Db;

class CategoriesController extends RestBaseController
{
    protected $categoryModel;

    public function __construct(PortalCategoryModel $categoryModel)
    {
        parent::__construct();
        $this->categoryModel = $categoryModel;
    }

    public function tab1()
    {
        $where = array(
            //            'parent_id' => 0,
            'delete_time' => 0,
            'parent_id' => 30
        );
        $data = Db::name('portal_category')->where($where)->select();//生活娱乐下的省
        $list = $data->all();
        foreach ($list as $k => $v) {

            $shi = $this->all($v['id']);
            $list[$k]['shi'] = [];
            $list[$k]['shi'] = array_merge($list[$k]['shi'], $shi);
            //            $list[$k]['shi']=$shi;
        }
        $this->success('请求成功!', $list);
    }

    public function test()
    {
        $where = array(
            'parent_id' => 0,
            'delete_time' => 0,
            //            'parent_id' => 34
        );
        $data = Db::name('portal_category')->where($where)->select();//生活娱乐下的省
        foreach ($data as $key => &$value) {
            $where1 = array(
                'parent_id' => $value['id'],
                'delete_time' => 0,
            );
            $data1 = Db::name('portal_category')->where($where1)->select();//生活娱乐下的省

            foreach ($data1 as $key1 =>&$value1){
                $where1 = array(
                    'parent_id' => $value1['id'],
                    'delete_time' => 0,
                );
                $data2 = Db::name('portal_category')->where($where1)->select();//生活娱乐下的省
                $value1['data2']=$data2;
            }
            $value['data1']=$data1;
        }
    }

    public function tab()
    {
        $where = array(
            //            'parent_id' => 0,
            'delete_time' => 0,
            'parent_id' => 34
        );
        $data = Db::name('portal_category')->where($where)->select();//生活娱乐下的省
        $list = $data->all();
        foreach ($list as $k => $v) {

            $shi = $this->all($v['id']);
            $list[$k]['shi'] = [];
            $list[$k]['shi'] = array_merge($list[$k]['shi'], $shi);
            //            $list[$k]['shi']=$shi;
        }
        $this->success('请求成功!', $list);
    }

    /**
     * 获取该id下的子id
     */
    public function getSon()
    {
        $where = array(
            //            'parent_id' => 0,
            'delete_time' => 0,
            'parent_id' => 34
        );
        $arr[][][] = array();
        $data = Db::name('portal_category')->where($where)->select();//生活娱乐下的省
        foreach ($data as $key => $value) {//$value 具体的省
            $where1 = array(
                'delete_time' => 0,
                'parent_id' => $value['id']
            );
            $arr[$key] = $value;

            $data1 = Db::name('portal_category')->where($where1)->select();//市
            foreach ($data1 as $key1 => $value1) {//具体的市
                $where2 = array(
                    'delete_time' => 0,
                    'parent_id' => $value1['id']
                );
                $value[$key1] = $value1;
                array_push($value[$key1], $value1);

                $data2 = Db::name('portal_category')->where($where2)->select();//市

                foreach ($data2 as $key2 => $value2) {//具体的区
                    array_push($value1[$key2], $value2);

                    //                    return $value2;
                }
            }
            //            return $data1;
            //            $xixi['more1'] = $data1;

        }
        $this->success('请求成功!', $arr);
    }

    /**
     * 获取分类列表
     */
    public function index()
    {
        $params = $this->request->get();
        $data = $this->categoryModel->getDatas($params);
        $this->success('请求成功!', $data);
    }

    /**
     * 显示指定的分类
     * @param int $id
     */
    public function read($id)
    {
        $params = $this->request->get();
        $params['id'] = $id;
        $data = $this->categoryModel->getDatas($params);
        $this->success('请求成功!', $data);
    }

    public function allSubCategories($categoryId)
    {

        $categoryId = intval($categoryId);

        if ($categoryId !== 0) {
            $category = $this->categoryModel->field('path')->where('id', $categoryId)->find();

            if (empty($category)) {
                return [];
            }

            $categoryPath = $category['path'];
        } else {
            $categoryPath = 0;
        }

        $where = [
            'status' => 1,
            'delete_time' => 0,
            'path' => ['like', "$categoryPath-%"]
        ];

        return $this->categoryModel->where($where)->select();
    }

    public function subCategories1($categoryId)
    {

        $where = [
            'status' => 1,
            'delete_time' => 0,
            'parent_id' => $categoryId
        ];

        return $this->categoryModel->where($where)->select();
    }

    /**
     * 返回指定分类其及子分类
     * @param int $categoryId 分类id
     * @return false|\PDOStatement|string|\think\Collection     返回指定分类其及子分类
     */
    public function all($categoryId = 0)
    {
        //        echo 'a';
        $where = [
            'status' => 1,
            'delete_time' => 0,
            'parent_id' => $categoryId
        ];

        $res = $this->categoryModel->where($where)->select();
        $oO = [];

        foreach ($res as $item) {
            //            return $item;
            $id = $item->id;
            $item = json_decode($item, true);
            $cao = $this->subCategories1($id);

            $arr = json_decode($cao, true);

            $item['a'] = [];
            array_push($item['a'], $arr);

            //            foreach ($arr as $v){
            //                $vid = $v->id;
            //                $v = json_decode($v,true);
            //                $cao1 = $this->subCategories1($vid);
            //
            //                $arr1 = json_decode($cao1, true);
            //                $item['b'] = [];
            //                array_push($v['b'], $arr);
            //
            //            }
            //


            //            json_encode($item);
            array_push($oO, $item);
            //           return $this->categoryModel->where(['id'=>$findId])->find(['path']);

            //            return $item;
        }
        return $oO;
        //        ('请求成功!', $oO);
    }
}
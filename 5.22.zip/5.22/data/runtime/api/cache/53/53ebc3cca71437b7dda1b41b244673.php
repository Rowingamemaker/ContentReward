<?php
//000000000000
 exit();?>
a:1:{s:8:"storages";a:1:{s:5:"Qiniu";a:2:{s:4:"name";s:15:"七牛云存储";s:6:"driver";s:24:"\plugins\qiniu\lib\Qiniu";}}}
<?php
//000000000000
 exit();?>
O:16:"think\Collection":1:{s:8:" * items";a:2:{i:0;a:2:{s:4:"hook";s:29:"send_mobile_verification_code";s:6:"plugin";s:14:"MobileCodeDemo";}i:1;a:2:{s:4:"hook";s:17:"fetch_upload_view";s:6:"plugin";s:5:"Qiniu";}}}
<?php
//000000000000
 exit();?>
s:97:"G:\xampp2\PHPTutorial\WWW\5.22\public/../data/runtime/cache\c3\0b008a754ac7f1eeef085057ee3106.php";
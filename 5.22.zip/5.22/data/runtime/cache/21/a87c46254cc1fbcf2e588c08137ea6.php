<?php
//000000000000
 exit();?>
a:7:{s:9:"from_name";s:15:"211程序开发";s:4:"from";s:19:"15959267720@163.com";s:4:"host";s:12:"smtp.163.com";s:11:"smtp_secure";s:3:"ssl";s:4:"port";s:3:"465";s:8:"username";s:19:"15959267720@163.com";s:8:"password";s:10:"zaijian886";}
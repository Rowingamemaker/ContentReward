<?php

namespace app\portal\controller;

use app\admin\model\RouteModel;
use cmf\controller\AdminBaseController;
use app\portal\model\PortalPostModel;
use app\portal\service\PostService;
use app\admin\model\ThemeModel;
use think\Db;

class AdminOrderController extends AdminBaseController
{
    public function index()
    {

        $order = Db::name('order')->order('id', 'desc')->paginate(10);
//        return json($order);
        $this->assign('pages', $order->items());
        $this->assign('page', $order->render());
        return $this->fetch();
    }


}

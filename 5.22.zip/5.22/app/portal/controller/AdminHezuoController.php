<?php
/**
 * Created by PhpStorm.
 * User: Rowin
 * Date: 2018/5/23
 * Time: 23:39
 */

namespace app\portal\controller;


use cmf\controller\AdminBaseController;
use think\Db;

class AdminHezuoController extends AdminBaseController
{
    public function index()
    {
        $hezuo=Db::name('hezuo')->where('id',1)->find();
        $this->assign('post',$hezuo);
        return $this->fetch();
    }

    /**
     * @return array
     */
    public function editPost()
    {
        $params=input();
        $post_content=$params['post'];
        $data=array(
            'post_content'=>$post_content
        );
        Db::name('hezuo')->where('id',1)->update($data);
        return $this->fetch('index');
    }
}